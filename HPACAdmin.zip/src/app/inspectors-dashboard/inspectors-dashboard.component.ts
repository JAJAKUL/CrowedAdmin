import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inspectors-dashboard',
  templateUrl: './inspectors-dashboard.component.html',
  styleUrls: ['./inspectors-dashboard.component.scss']
})
export class InspectorsDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
