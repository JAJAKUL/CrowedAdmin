import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-underconstruction',
  templateUrl: './page-underconstruction.component.html',
  styleUrls: ['./page-underconstruction.component.scss']
})
export class PageUnderconstructionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
