import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PageUnderconstructionRoutingModule } from './page-underconstruction-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PageUnderconstructionRoutingModule
  ]
})
export class PageUnderconstructionModule { }
