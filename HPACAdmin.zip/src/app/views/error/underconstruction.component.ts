import { Component } from '@angular/core';

@Component({
  templateUrl: 'underconstruction.component.html'
})
export class UnderconstructionComponent {

  constructor() { }

}
